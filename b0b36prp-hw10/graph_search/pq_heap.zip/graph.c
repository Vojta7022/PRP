#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "graph.h"

// void load_bin(const char *fname, graph_t *graph)
// {
//     FILE *f = fopen(fname, "rb");
//     if (!f)
//     {
//         fprintf(stderr, "Error: Cannot open file %s\n", fname);
//         exit(EXIT_FAILURE);
//     }

//     int from, to, cost;
//     while (fread(&from, sizeof(int), 1, f) == 1 &&
//            fread(&to, sizeof(int), 1, f) == 1 &&
//            fread(&cost, sizeof(int), 1, f) == 1)
//     {
//         if (graph->num_edges >= graph->capacity)
//         {
//             graph = enlarge_graph(graph);
//         }
//         graph->edges[graph->num_edges].from = from;
//         graph->edges[graph->num_edges].to = to;
//         graph->edges[graph->num_edges].cost = cost;
//         graph->num_edges++;
//     }
//     fclose(f);
// }

// void save_bin(const graph_t *const graph, const char *fname)
// {
//     FILE *f = fopen(fname, "wb");
//     if (!f)
//     {
//         fprintf(stderr, "Error: Cannot open file %s\n", fname);
//         exit(EXIT_FAILURE);
//     }

//     for (int i = 0; i < graph->num_edges; i++)
//     {
//         fwrite(&graph->edges[i].from, sizeof(int), 1, f);
//         fwrite(&graph->edges[i].to, sizeof(int), 1, f);
//         fwrite(&graph->edges[i].cost, sizeof(int), 1, f);
//     }
//     fclose(f);
// }

// void write_int(FILE *f, int value)
// {
//     if (value < 0)
//     {
//         putc('-', f);
//         value = -value;
//     }

//     char buffer[12];
//     int i = 0;

//     do
//     {
//         buffer[i++] = '0' + (value % 10);
//         value /= 10;
//     } while (value > 0);

//     while (i > 0)
//     {
//         putc(buffer[--i], f);
//     }
// }
